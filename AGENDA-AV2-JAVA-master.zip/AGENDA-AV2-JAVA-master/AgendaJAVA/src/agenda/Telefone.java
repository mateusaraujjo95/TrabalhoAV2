
package agendacomercial;


public class Telefone {
    int id_phone;
    int ddi, ddd, c_operadora;
    int numero;
    String tipo;
    int fk;
}
