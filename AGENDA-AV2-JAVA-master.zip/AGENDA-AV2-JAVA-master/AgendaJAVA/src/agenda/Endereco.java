
package agendacomercial;


public class Endereco {
   int id_end;
   String tipo, logradouro, num, compl;
   String bairro, cidade, uf, pais;
   int cep;
   String categoria;
   int fk;
}
